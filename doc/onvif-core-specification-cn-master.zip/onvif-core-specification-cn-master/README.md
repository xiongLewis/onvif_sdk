# ONVIF Core Specification 翻译

内容基于 Version 2.3 (2013,五月)的版本。

## 开始阅读

[开始阅读](ebook/preface.md)
